# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Common Development Commands

- **Development server**: `npm run dev` - Starts Next.js development server on port 3000
- **Build**: `npm run build` - Creates production build
- **Production start**: `npm run start` - Starts production server on port 80
- **Linting**: `npm run lint` - Runs ESLint checks
- **Deploy**: `npm run deploy` - Builds and starts production server

### Database Operations
- All database operations are now handled directly through Supabase
- Use Supabase Dashboard for database management and migrations
- **Testing**: Use individual API route testing endpoints in `/api/test/` directory

## Tech Stack Architecture

**DarkCloud** is a cloud VM management platform built with Next.js that enables users to create and manage Azure virtual machines with integrated payment processing and Discord authentication.

### Core Technologies
- **Framework**: Next.js 15+ with App Router and TypeScript
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth with Discord OAuth
- **Cloud Integration**: Azure SDK (@azure/arm-compute, @azure/arm-network) + AWS SDK (EC2)
- **Payment Processing**: Multiple gateways (EFI/GerenciaNet, OpenPix, PagarMe)
- **UI Components**: Radix UI with TailwindCSS and shadcn/ui + NextUI
- **State Management**: Zustand
- **AI Integration**: Google Gemini API for intelligent chat support
- **Form Handling**: React Hook Form with Zod validation
- **Charts & Visualization**: Recharts for analytics dashboards

### Database Architecture

The application uses a **hybrid approach**:
- **Supabase Auth**: For authentication and row-level security
- **Supabase ORM**: Direct PostgreSQL access for complex operations and better performance

Key database tables in Supabase:
- **`plans`**: Subscription plans with dual provisioning modes (automatic/queue-based) and stock management
- **`user_plans`**: Active user subscriptions with expiration tracking
- **`stock_pools`**: Shared inventory pools for queue-based plans
- **`queue`**: Queue management for limited-availability plans
- **`auto_queue`**: Advanced time-slot based queue system with session management
- **`time_slots`**: Time-based slot allocation for auto queue VMs
- **`machines`**: VM instances with Azure integration and status tracking
- **`payments`**: Payment transaction records with gateway support
- **`profiles`**: User profiles with admin levels (user/admin/owner)
- **`coupons`** & **`coupon_usages`**: Discount system with usage tracking
- **`disk_sessions`**: Session management for disk-based VMs with activity tracking
- **`disk_vms`**: Specialized VM instances for disk management
- **`user_disks`**: User persistent disk storage allocation
- **`ai_configs`**: AI system configuration and API keys management

### Hybrid Controller Pattern

Database operations use a **hybrid approach** combining Supabase auth with Supabase ORM:

**Authentication**: Use `AuthHybrid` utility for auth + permission checks
```typescript
import { AuthHybrid } from '@/lib/auth-hybrid';
const user = await AuthHybrid.getAuthenticatedUser();
const isAdmin = await AuthHybrid.isAdmin(user.id);
const isOwner = await AuthHybrid.isOwner(user.id);
```

**Database Operations**: Use Supabase controllers for complex queries (prefer .ts over .tsx versions)
```typescript
import plansController from '@/functions/database/controllers/PlansController';
import userPlanController from '@/functions/database/controllers/UserPlanController';
import paymentControllerSupabase from '@/functions/database/controllers/PaymentControllerSupabase';
import usersController from '@/functions/database/controllers/UsersController';

// Complex queries with JOINs and better performance
const activePlans = await plansController.findActive();
const userPlans = await userPlanController.getUserActivePlans(userId);
```

**Database Schema**: Full TypeScript definitions with relations in `src/lib/db/schema.ts`

### API Route Structure

API routes follow Next.js App Router conventions in `src/app/api/`:
- **Authentication**: All routes verify user session via Supabase
- **Authorization**: Admin-only routes check `admin_level` in profiles table
- **Error Handling**: Standardized error responses with proper HTTP status codes
- **Security**: Malicious access attempts logged via `AuthHybrid.sendSecurityWebhook()`

Key API patterns:
- `GET /api/admin/*` - Admin-only endpoints with role verification
- `POST /api/queue/join` - Queue management with plan validation
- `POST /api/queue/auto/*` - Advanced auto-queue system endpoints
- `GET /api/gateways/*` - Payment gateway configuration endpoints
- `POST /api/ai/chat` - AI chat conversations with Gemini
- `GET|POST /api/ai/config/*` - AI system configuration management
- `GET /api/disks/*` - User disk management and session tracking
- `GET /api/admin/disks/*` - Admin disk and session monitoring
- `*/route.ts` - Standard Next.js API route files

### Azure Integration

VM management is handled through Azure SDK integration:
- **Configuration**: `src/lib/azure.ts` with environment validation
- **VM Operations**: Create/start/stop/delete via Azure Compute Client
- **Resource Management**: Resource group and subscription through environment variables
- **Snapshot Support**: VM creation from snapshots for consistent environments
- **Status Tracking**: Dual status system (Azure status + system status)

### Payment Gateway Architecture

Multiple payment processors supported with unified interface:
- **EFI/GerenciaNet**: PIX payments with certificate authentication (`EfiPaymentService.ts`)
- **OpenPix**: PIX payments with App ID authentication (`OpenPixPaymentService.ts`)
- **Webhook Handlers**: Transaction status updates in `/api/webhook/efi/` and `/api/webhook/openpix/`
- **Gateway Management**: Admin configuration through `/api/gateways/` endpoints

### Advanced Queue Systems

Two queue systems for different use cases:

**1. Basic Queue**: Traditional position-based queue
- Simple FIFO ordering with position tracking
- Plan validation and duration management
- Admin controls for activation/deactivation

**2. Auto Queue**: Time-slot based system with advanced features
- **Time Slots**: Pre-allocated time windows in `time_slots` table
- **Session Management**: User sessions with duration tracking
- **Spot Warnings**: Notifications before session expiry
- **Disk Snapshots**: User data persistence between sessions
- **Auto Creation**: System-generated time slots for availability

### Plan Management System

Sophisticated plan architecture with multiple provisioning modes:
1. **Individual Plans**: Direct VM assignment with personal stock
2. **Queue Manual**: Manual admin allocation from shared pools
3. **Queue Auto**: Automated time-slot allocation system

Plan features:
- Duration-based subscriptions (daily billing)
- Stock management (individual vs. pool-based vs. time-slot)
- Highlight colors for premium plans
- VM configuration templates in JSONB format
- Expiration tracking with automated cleanup

### Environment Configuration

Required environment variables (see `env.example`):
- **Supabase**: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
- **Discord**: OAuth credentials and multiple webhook URLs for different purposes
- **Azure**: `AZURE_SUBSCRIPTION_ID`, `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`, `AZURE_RESOURCE_GROUP_NAME`
- **AWS**: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION` for EC2 integration
- **Payment Gateways**: API keys and certificates for each provider (EFI, OpenPix, PagarMe)
- **AI Integration**: `GEMINI_API_KEY` for Google Gemini API access
- **Database**: `DATABASE_URL` for direct Supabase ORM connection

### Security Considerations

- Server-side authentication validation on all protected routes
- Admin role verification with malicious access logging via Discord webhooks
- Environment variable validation and error handling in Azure configuration
- Certificate-based authentication for payment gateways
- Session management through Supabase middleware
- Security webhook notifications for unauthorized access attempts

### File Structure Notes

- `src/components/admin/`: Admin panel components with tab-based organization
- `src/lib/`: Service integrations and utility functions
- `src/lib/db/`: Database schema and connection configuration  
- `src/utils/supabase/`: Supabase client configurations for different contexts
- `src/services/`: Business logic services (payment, VM management, etc.)
- Multiple controller files exist (.ts and .tsx) - **always prefer .ts versions for new work**
- `src/app/api/test/`: Development and debugging API endpoints for testing individual services

### AI Chat System

Integrated intelligent support system using Google Gemini:
- **AI Configuration**: `/api/ai/config/` endpoints for API key and model management
- **Chat Interface**: `/api/ai/chat/` for real-time AI conversations
- **Admin Controls**: AI configuration management through admin panel
- **Smart Responses**: Context-aware assistance for users and troubleshooting
- **Configuration Storage**: AI settings stored in `ai_configs` table

### Advanced Disk Management System

Comprehensive persistent storage solution:
- **`DiskController.ts`**: Manages disk allocation and user data persistence
- **`DiskSessionMonitorService.ts`**: Monitors session activity and disk usage
- **Session Management**: Advanced session tracking with `disk_sessions` table
- **Activity Monitoring**: Real-time session activity and automatic warnings
- **Disk APIs**: `/api/disks/` and `/api/admin/disks/` for comprehensive disk management
- **VM Integration**: Specialized `disk_vms` for persistent storage scenarios
- **User Storage**: Individual disk allocation through `user_disks` table
- **Session Lifecycle**: Complete session management from creation to termination