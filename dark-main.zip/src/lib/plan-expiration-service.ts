// Plan expiration checker removed - functionality moved to UserPlanController

export function initializePlanExpirationService() {
  // Functionality moved to UserPlanController.checkExpiredPlans()
  // This should be called by a cron job or scheduled function
  console.log('[PlanExpirationService] Service disabled - use scheduled functions instead');
} 